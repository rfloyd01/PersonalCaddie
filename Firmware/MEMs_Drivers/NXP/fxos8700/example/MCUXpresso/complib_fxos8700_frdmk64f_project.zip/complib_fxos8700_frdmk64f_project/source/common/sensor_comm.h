/*
 * Copyright 2018-2019 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * @file  sensor_comm.h
 * @brief This header contains common definitions for sensor communication interface function.
   This is virtual definition of the sensor communication interface depends on how it connected to MCU peripherals	
*/

#ifndef SENSOR_COMM_H_
#define SENSOR_COMM_H_

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <stdint.h>

/*  SDK Included Files */
#include "board.h"
#include "fsl_i2c.h"
#include "fsl_smc.h"
#include "pin_mux.h"
#include "clock_config.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define FXOS8700_BB_SLAVEADDR    0x1DU    /* Sensor Default I2C Slave Address on Base-Board */
#define FXOS8700_SB_SLAVEADDR    0x1EU    /* Sensor Default I2C Slave Address on Shield-Board */

#define FXOS8700_SLAVEADDR       FXOS8700_SB_SLAVEADDR

/* Sensor Interface I2C Bus Configuration */
#define I2C_BAUDRATE             100000U
#define I2C_DEVICE_NAME          I2C1
#define I2C_CLOCK_FREQUENCY      CLOCK_GetFreq(I2C1_CLK_SRC)
/*******************************************************************************
 * Typedefs
 ******************************************************************************/

/*!
 * @brief Sensor Interface Error Type.
 */
typedef struct sensor_comm_handle
{
    void *pComm;
	uint8_t error;
}sensor_comm_handle_t;
/*******************************************************************************
 * Constants
 ******************************************************************************/

/*******************************************************************************
 * Global Variables
 ******************************************************************************/

/*! @brief I2C master handle structure. */
typedef struct sensor_i2c_handle
{
	i2c_master_handle_t g_i2cSensorHandle;
	uint16_t slaveAddr;
} sensor_i2c_handle_t;
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
uint8_t sensor_comm_init(sensor_comm_handle_t *pComHandle);
uint8_t sensor_comm_write(sensor_comm_handle_t *pComHandle, uint16_t offset, uint16_t size, uint8_t *pWritebuffer);
uint8_t sensor_comm_read(sensor_comm_handle_t *pComHandle, uint16_t offset, uint16_t size, uint8_t *pReadbuffer);
#endif /* SENSOR_COMM_H_ */
