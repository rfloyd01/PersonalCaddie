/*
 * Copyright 2018-2019 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * @file sensor_comm.c
 * @brief The sensor_comm.c file implements the sensor communication virtual interface. 
   User application needs to implement/call underlying SDK communication interfaces such i2c/SPI. 
   This is the SDK agnostic layer for the sensor for communication.
 */

//-----------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------

/* CompLib Included Files */
#include "sensor_comm.h"
#include "sensor_common.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define TRUE    1
#define FALSE   0

/*******************************************************************************
 * Global Variables
 ******************************************************************************/
volatile bool g_completionFlag = FALSE, g_nakFlag = FALSE;
//i2c_master_handle_t g_i2cSensorHandle;
//-----------------------------------------------------------------------
// Functions
//-----------------------------------------------------------------------

/*! @brief I2C Master Event Handler */
void sensor_i2c_handler(I2C_Type *base, i2c_master_handle_t *handle, status_t status, void *userData)
{
    /* Signal transfer success when received SUCCESS status. */
    if(status == kStatus_Success)
    {
        g_completionFlag = TRUE;
    }
    /* Signal transfer failure when received NAK status. */
    if(status == kStatus_I2C_Nak)
    {
        g_nakFlag = TRUE;
    }
}

uint8_t sensor_comm_init(sensor_comm_handle_t *pComHandle)
{
    i2c_master_config_t masterConfig;

    /* Initialize I2C Bus. */
    I2C_MasterGetDefaultConfig(&masterConfig);
    masterConfig.baudRate_Bps = I2C_BAUDRATE;
    I2C_MasterInit(I2C_DEVICE_NAME, &masterConfig, I2C_CLOCK_FREQUENCY);
    I2C_MasterTransferCreateHandle(I2C_DEVICE_NAME, &((sensor_i2c_handle_t *)pComHandle->pComm)->g_i2cSensorHandle, sensor_i2c_handler, NULL);
    ((sensor_i2c_handle_t *)pComHandle->pComm)->slaveAddr = FXOS8700_SLAVEADDR;
    //I2C_MasterTransferCreateHandle(I2C_DEVICE_NAME, &g_i2cSensorHandle, sensor_i2c_handler, NULL);->
    return SENSOR_SUCCESS;
}

uint8_t sensor_comm_write(sensor_comm_handle_t *pComHandle, uint16_t offset, uint16_t size, uint8_t *pWritebuffer)
{
    I2C_Type *base = I2C_DEVICE_NAME;
    status_t reVal = kStatus_Fail;
    i2c_master_transfer_t masterXfer;

    memset(&masterXfer, 0, sizeof(masterXfer));
    masterXfer.slaveAddress   = ((sensor_i2c_handle_t *)pComHandle->pComm)->slaveAddr;
    masterXfer.direction      = kI2C_Write;
    masterXfer.subaddress     = offset;
    masterXfer.subaddressSize = 1;
    masterXfer.data           = pWritebuffer;
    masterXfer.dataSize       = size;
    masterXfer.flags          = kI2C_TransferDefaultFlag;

    g_nakFlag        = FALSE;
    g_completionFlag = FALSE;
    /* Block write registers. */
    reVal = I2C_MasterTransferNonBlocking(base, &((sensor_i2c_handle_t *)pComHandle->pComm)->g_i2cSensorHandle, &masterXfer);
    if(reVal != kStatus_Success)
    {
        return SENSOR_WRITE_ERR;
    }

    /*  wait for transfer completion. */
    while((!g_nakFlag) && (!g_completionFlag))
    {
        SMC_SetPowerModeWait(SMC); // Sleep while waiting for completion
    }

    if(g_nakFlag == FALSE)
    {
        return SENSOR_SUCCESS;;
    }
    else
    {
        return SENSOR_WRITE_ERR;
    }
}

uint8_t sensor_comm_read(sensor_comm_handle_t *pComHandle, uint16_t offset, uint16_t size, uint8_t *pReadbuffer)
{
    I2C_Type *base = I2C_DEVICE_NAME;
    status_t reVal = kStatus_Fail;
    i2c_master_transfer_t masterXfer;

    memset(&masterXfer, 0, sizeof(masterXfer));
    masterXfer.slaveAddress   = ((sensor_i2c_handle_t *)pComHandle->pComm)->slaveAddr;
    masterXfer.direction      = kI2C_Read;
    masterXfer.subaddress     = offset;
    masterXfer.subaddressSize = 1;
    masterXfer.data           = pReadbuffer;
    masterXfer.dataSize       = size;
    masterXfer.flags          = kI2C_TransferDefaultFlag;

    g_nakFlag        = FALSE;
    g_completionFlag = FALSE;
    /* Block read registers. */
    reVal = I2C_MasterTransferNonBlocking(base, &((sensor_i2c_handle_t *)pComHandle->pComm)->g_i2cSensorHandle, &masterXfer);
    if(reVal != kStatus_Success)
    {
        return SENSOR_READ_ERR;
    }

    /*  Wait for transfer completion. */
    while((!g_nakFlag) && (!g_completionFlag))
    {
        SMC_SetPowerModeWait(SMC); // Sleep while waiting for completion
    }

    if(g_nakFlag == FALSE)
    {
        return SENSOR_SUCCESS;
    }
    else
    {
        return SENSOR_READ_ERR;
    }
}
