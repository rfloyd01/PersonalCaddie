/*
 * Copyright 2019 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*  SDK Included Files */
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_i2c.h"
#include "pin_mux.h"
#include "clock_config.h"

/* CompLib Included Files */
#include "sensor_comm.h"
#include "fxos8700_driver.h"
#include "sensor_common.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/


/*******************************************************************************
 * Global Variables
 ******************************************************************************/
/* Metadata instances */
fxos8700_driver_t    g_fxos8700_comm_handle;
sensor_i2c_handle_t  g_fxos8700_i2c_handle;
sensor_comm_handle_t g_comm_handle;

/*******************************************************************************
 * Code
 ******************************************************************************/

/*!
 * @brief Main function
 */
int main(void)
{

    uint8_t status;
    uint8_t eventFlag = 0;
    static uint8_t resumeApp = false;

    /* Initialize MCU Board and Peripherals */
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_I2C_ConfigurePins();
    BOARD_InitDebugConsole();

    PRINTF("\r\n FXOS8700 Orientation Detection CompLib Example.\r\n");

    /*! Initialize FXOS8700 comm handle instance */
    g_fxos8700_comm_handle.pComHandle = &g_comm_handle;
	g_fxos8700_comm_handle.pComHandle->pComm = &g_fxos8700_i2c_handle;

	/*! Initialize FXOS8700 communication interface */
    status = fxos8700_init(&g_fxos8700_comm_handle);
    if(status != SENSOR_SUCCESS)
    {
		PRINTF("\r\n FXOS8700 Comm Init Failed!!!\r\n");
        return status;
    }

    SMC_SetPowerModeVlpr(SMC, false);

	/*! Configure FXOS8700 to set Orientation detection mode. */
    status = fxos8700_set_embedded_function(&g_fxos8700_comm_handle, FXOS8700_ORIENT_DETECTION_MODE);
	if(status != SENSOR_SUCCESS)
    {
		PRINTF("\r\n FXOS8700 Configure Operation Failed!!!\r\n");
        return status;
    }

    for (;;)
    {
    	eventFlag = 0;
        /*! Read the orient data from the FXOS8700. */
    	status = fxos8700_read_event(&g_fxos8700_comm_handle, FXOS8700_ORIENTATION, &eventFlag);
        if (status != SENSOR_SUCCESS)
        {
            PRINTF("\r\n FXOS8700 Event Read Failed. \r\n");
            return -1;
        }

		/*! Check the eventFlag and identify type of orientation detected. */
        if (eventFlag != FXOS8700_NO_EVENT_DETECTED)
        {

			switch (eventFlag)
			{
				case FXOS8700_PORTRAIT_UP:

					PRINTF("\r\n FXOS8700 Orientation Detected - PORTRAIT UP \r\n");
					resumeApp = true;
					break;
				case FXOS8700_PORTRAIT_DOWN:

					PRINTF("\r\n FXOS8700 Orientation Detected - PORTRAIT DOWN \r\n");
					resumeApp = true;
					break;
				case FXOS8700_LANDSCAPE_RIGHT:

					PRINTF("\r\n FXOS8700 Orientation Detected - LANDSCAPE RIGHT \r\n");
					resumeApp = true;
					break;
				case FXOS8700_LANDSCAPE_LEFT:

					PRINTF("\r\n FXOS8700 Orientation Detected - LANDSCAPE LEFT \r\n");
					resumeApp = true;
					break;
				case FXOS8700_FRONT_SIDE:

					PRINTF("\r\n FXOS8700 Orientation Detected - FRONT SIDE \r\n");
					resumeApp = true;
					break;
				case FXOS8700_BACK_SIDE:

					PRINTF("\r\n FXOS8700 Orientation Detected - BACK SIDE \r\n");
					resumeApp = true;
					break;
				default:
					status = SENSOR_INVALIDPARAM_ERR;
					break;
			}
        }

        if (resumeApp)
        {
            PRINTF("\r\n\r\n Change the Orientation and Press any key to continue... \r\n");
            GETCHAR();
            resumeApp = false;
        }
    }
}
