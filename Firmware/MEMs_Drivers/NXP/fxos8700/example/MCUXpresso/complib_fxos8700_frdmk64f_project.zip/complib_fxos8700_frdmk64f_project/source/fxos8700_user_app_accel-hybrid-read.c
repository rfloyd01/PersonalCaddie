/*
 * Copyright 2019 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*  SDK Included Files */
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_i2c.h"
#include "pin_mux.h"
#include "clock_config.h"

/* CompLib Included Files */
#include "sensor_comm.h"
#include "fxos8700_driver.h"
#include "sensor_common.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define MAX_SAMPLE_RUN 500

/*******************************************************************************
 * Prototypes
 ******************************************************************************/


/*******************************************************************************
 * Global Variables
 ******************************************************************************/
/* Metadata instances */
fxos8700_driver_t    g_fxos8700_comm_handle;
sensor_i2c_handle_t  g_fxos8700_i2c_handle;
sensor_comm_handle_t g_comm_handle;

/*******************************************************************************
 * Code
 ******************************************************************************/

/*!
 * @brief Main function
 */
int main(void)
{

    uint8_t status;
    uint32_t samplesCount = 0;
    fxos8700_data_t data;

    /* Initialize MCU Board and Peripherals */
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_I2C_ConfigurePins();
    BOARD_InitDebugConsole();

    PRINTF("\r\n FXOS8700 Hybrid Mode CompLib Example -- Read Accel & Mag samples in polling mode.\r\n");

    /* Initialize FXOS8700 comm handle instance */
    g_fxos8700_comm_handle.pComHandle = &g_comm_handle;
	g_fxos8700_comm_handle.pComHandle->pComm = &g_fxos8700_i2c_handle;

	/* Initialize FXOS8700 communication interface */
    status = fxos8700_init(&g_fxos8700_comm_handle);
    if(status != SENSOR_SUCCESS)
    {
		PRINTF("\r\n FXOS8700 Comm Init Failed!!!\r\n");
        return status;
    }

	/* Configure FXOS8700 with 25Hz ODR in Hybrid Mode, Read Accel and Mag samples in polling mode. */
    status = fxos8700_configure_hybrid(&g_fxos8700_comm_handle, FXOS8700_ODR_HYBRID_25_HZ, FXOS8700_HYBRID_READ_POLL_MODE);
	if(status != SENSOR_SUCCESS)
    {
		PRINTF("\r\n FXOS8700 Configure Operation Failed!!!\r\n");
        return status;
    }

    for (;;)
    {

        /*! Read the sensor data from the fxos8700. */
    	status = fxos8700_read_data(&g_fxos8700_comm_handle, FXOS8700_ACCEL_MAG_HYBRID, &data);
        if (status != SENSOR_SUCCESS)
        {
            PRINTF("\r\n FXOS8700 Data Read Failed. \r\n");
            return -1;
        }

        samplesCount++;
        /* Print Accel and Mag samples on serial debug terminal. */
        PRINTF("\r\n [%d]\tFXOS8700 Accel (X) = %d  (Y) = %d  (Z) = %d\r\n", samplesCount, data.accel[0], data.accel[1], data.accel[2]);
        PRINTF("\r\n [%d]\tFXOS8700 Mag   (X) = %d  (Y) = %d  (Z) = %d\r\n", samplesCount, data.mag[0], data.mag[1], data.mag[2]);
        PRINTF("\r\n");

        if (MAX_SAMPLE_RUN == samplesCount)
        {
        	break;
        }
    }

    PRINTF("\r\n Extracted configured no. of samples = %d\r\n", samplesCount);
    PRINTF("\r\n\r\n End of Application\r\n", samplesCount);
    return 0;
}
