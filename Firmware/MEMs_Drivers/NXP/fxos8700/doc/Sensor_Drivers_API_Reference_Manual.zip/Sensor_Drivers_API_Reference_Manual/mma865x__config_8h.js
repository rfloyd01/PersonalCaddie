var mma865x__config_8h =
[
    [ "FIFO_SIZE", "mma865x__config_8h.html#a6092455278a1ac67204e0dbe08f9d13f", null ],
    [ "gMma865x8bitAccelPollConfig", "mma865x__config_8h.html#a5f1bd05fcf060dabe21897e1dde25d42", null ],
    [ "gMma865xAccelFifoConfig", "mma865x__config_8h.html#ad4e3897a15caf17b00a6407e41420c79", null ],
    [ "gMma865xAccelInterruptConfig", "mma865x__config_8h.html#aec98c112adfc1733a2a4608e3edd2209", null ],
    [ "gMma865xAccelPollConfig", "mma865x__config_8h.html#a5c4db9b0a926f84ead616373fddd0ee1", null ],
    [ "gMma865xActiveModeConfig", "mma865x__config_8h.html#a9a4afdac62389b64b0652617ac2ff397", null ],
    [ "gMma865xDoubleTapDetectConfig", "mma865x__config_8h.html#af8b45f07dcc8a923928b0fba32c9a947", null ],
    [ "gMma865xFifoStatus", "mma865x__config_8h.html#a34aeb94d866bbf35dad962906d33ea28", null ],
    [ "gMma865xFreefallDetectConfig", "mma865x__config_8h.html#a54a017d4b78968b96ff3fe1c285389e7", null ],
    [ "gMma865xMotiontDetectConfig", "mma865x__config_8h.html#a1e4fb0e397c0726152fff782a26ab152", null ],
    [ "gMma865xOrientDetectConfig", "mma865x__config_8h.html#af878763f0412e0cdaa76228331dcf827", null ],
    [ "gMma865xReadAccel", "mma865x__config_8h.html#a256eed2d944add209133b64fe6de8218", null ],
    [ "gMma865xReadAccel8bit", "mma865x__config_8h.html#a6f03d3a96dc091059d84b3cfc9240e5c", null ],
    [ "gMma865xReadAccelFifo", "mma865x__config_8h.html#a89baaf179612c936858c6ba929cf7bc0", null ],
    [ "gMma865xReadFFMTSrc", "mma865x__config_8h.html#ac3c01d7a9ed173925b0bfd7ae279f3cf", null ],
    [ "gMma865xReadINTSrc", "mma865x__config_8h.html#a38a45d919b96ed6b72b6c52e1cecc5c2", null ],
    [ "gMma865xReadPLStatus", "mma865x__config_8h.html#ab947bf428bcd3cdeede97c3e1d6d33c8", null ],
    [ "gMma865xReadPulseSrc", "mma865x__config_8h.html#a84656d814b6abf79617e73be1b2b6c21", null ],
    [ "gMma865xReadStatus", "mma865x__config_8h.html#a53228390afe8504ff086cbda39c2c4fc", null ],
    [ "gMma865xStandbyModeConfig", "mma865x__config_8h.html#a87245eee848fa59d591fd76c7c9e9901", null ]
];