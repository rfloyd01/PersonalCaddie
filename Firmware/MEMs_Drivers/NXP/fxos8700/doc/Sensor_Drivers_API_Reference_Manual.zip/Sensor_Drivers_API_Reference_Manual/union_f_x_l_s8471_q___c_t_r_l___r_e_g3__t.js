var union_f_x_l_s8471_q___c_t_r_l___r_e_g3__t =
[
    [ "b", "union_f_x_l_s8471_q___c_t_r_l___r_e_g3__t.html#a3761e27df247c9f9d14ca5e7be6ffbdf", null ],
    [ "fifo_gate", "union_f_x_l_s8471_q___c_t_r_l___r_e_g3__t.html#af17964b4085bf0878f63eadcdf90a246", null ],
    [ "ipol", "union_f_x_l_s8471_q___c_t_r_l___r_e_g3__t.html#a107705cb4eae0abdc8c1b721d79ae772", null ],
    [ "pp_od", "union_f_x_l_s8471_q___c_t_r_l___r_e_g3__t.html#a14c3cfd5ae0507456f4bc0d9ce424dfb", null ],
    [ "w", "union_f_x_l_s8471_q___c_t_r_l___r_e_g3__t.html#aba9ed0487b0aa23eba534648df8384c0", null ],
    [ "wake_en_a_vecm", "union_f_x_l_s8471_q___c_t_r_l___r_e_g3__t.html#ae0e6e3b74c3878969f2b0a2c8e1dbf0b", null ],
    [ "wake_ff_mt", "union_f_x_l_s8471_q___c_t_r_l___r_e_g3__t.html#a88c7ccd43eced3e175495443fe5e0b9f", null ],
    [ "wake_lndprt", "union_f_x_l_s8471_q___c_t_r_l___r_e_g3__t.html#a58ad429468c16a34aee7da90020e1256", null ],
    [ "wake_pulse", "union_f_x_l_s8471_q___c_t_r_l___r_e_g3__t.html#a2734e00b0d0c3daf76683d5711080185", null ],
    [ "wake_trans", "union_f_x_l_s8471_q___c_t_r_l___r_e_g3__t.html#a3b13c5b6dd7aa995dbdaafa8c0ad14d9", null ]
];