var structfxos8700__data__t =
[
    [ "accel", "structfxos8700__data__t.html#a3bff62722c99df72cf560ed263edfb48", null ],
    [ "mag", "structfxos8700__data__t.html#a3dd21561abe88073096d790001af82e8", null ]
];