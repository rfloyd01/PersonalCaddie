var structfxls8962__accel__config =
[
    [ "control", "structfxls8962__accel__config.html#a6ea443f320f8c0e5309d2a2f71ab1531", null ],
    [ "fifosetup", "structfxls8962__accel__config.html#a2cd96e760dfc9b4df1dca4b038088401", null ]
];