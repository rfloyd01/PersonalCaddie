var union_f_x_l_s8471_q___p_l___c_f_g__t =
[
    [ "b", "union_f_x_l_s8471_q___p_l___c_f_g__t.html#aa2a4423ce5ab435fa832fe36fe63fb2c", null ],
    [ "dbcntm", "union_f_x_l_s8471_q___p_l___c_f_g__t.html#a0bd7c4ad567bf4f51fcc822b25ebc9c2", null ],
    [ "pl_en", "union_f_x_l_s8471_q___p_l___c_f_g__t.html#a89496c9e4c7e9a8d6d11b8e48721aea2", null ],
    [ "reserved", "union_f_x_l_s8471_q___p_l___c_f_g__t.html#acb7bc06bed6f6408d719334fc41698c7", null ],
    [ "w", "union_f_x_l_s8471_q___p_l___c_f_g__t.html#aba9ed0487b0aa23eba534648df8384c0", null ]
];