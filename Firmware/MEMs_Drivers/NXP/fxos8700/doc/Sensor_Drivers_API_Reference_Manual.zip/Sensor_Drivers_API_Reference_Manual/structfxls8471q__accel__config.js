var structfxls8471q__accel__config =
[
    [ "control", "structfxls8471q__accel__config.html#ace71a70733d7f57cffda022eab9489a2", null ],
    [ "fifosetup", "structfxls8471q__accel__config.html#a45d62ef0a871dd08a8c8393debc756c0", null ],
    [ "mode", "structfxls8471q__accel__config.html#a0b8947bed7fdc43bca1fe865fd7e1261", null ]
];