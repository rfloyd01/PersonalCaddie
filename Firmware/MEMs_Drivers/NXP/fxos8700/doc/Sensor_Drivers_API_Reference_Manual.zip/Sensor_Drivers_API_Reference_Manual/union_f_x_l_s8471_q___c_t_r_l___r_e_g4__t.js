var union_f_x_l_s8471_q___c_t_r_l___r_e_g4__t =
[
    [ "b", "union_f_x_l_s8471_q___c_t_r_l___r_e_g4__t.html#a6aeeac124c838cfc68459f6f544da323", null ],
    [ "int_en_a_vecm", "union_f_x_l_s8471_q___c_t_r_l___r_e_g4__t.html#a5c3ccd18159e18acf2a18ed162b987c8", null ],
    [ "int_en_aslp", "union_f_x_l_s8471_q___c_t_r_l___r_e_g4__t.html#ab904b5d973ad92a4469fd27ef705d9e4", null ],
    [ "int_en_drdy", "union_f_x_l_s8471_q___c_t_r_l___r_e_g4__t.html#a3da3937e469fcbd19ff2a154abbb6096", null ],
    [ "int_en_ff_mt", "union_f_x_l_s8471_q___c_t_r_l___r_e_g4__t.html#a6b81691eeeef4dd6f9f828083954292d", null ],
    [ "int_en_fifo", "union_f_x_l_s8471_q___c_t_r_l___r_e_g4__t.html#a7e2fafbd17a9ed53df22d1f4266a47a0", null ],
    [ "int_en_lndprt", "union_f_x_l_s8471_q___c_t_r_l___r_e_g4__t.html#a2297347913f69e2854f8651a409fd1ae", null ],
    [ "int_en_pulse", "union_f_x_l_s8471_q___c_t_r_l___r_e_g4__t.html#a716ca6937c5f9361633ccd865454b7a6", null ],
    [ "int_en_trans", "union_f_x_l_s8471_q___c_t_r_l___r_e_g4__t.html#af18ca516505c181dd5cfd627c0b0cc6f", null ],
    [ "w", "union_f_x_l_s8471_q___c_t_r_l___r_e_g4__t.html#aba9ed0487b0aa23eba534648df8384c0", null ]
];