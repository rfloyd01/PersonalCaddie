var structfxls8471q__driver =
[
    [ "comHandle", "structfxls8471q__driver.html#a8889120d03dd39ea05f4a2cc302429d7", null ]
];