var structmma865x__data__t =
[
    [ "accel", "structmma865x__data__t.html#a3bff62722c99df72cf560ed263edfb48", null ]
];