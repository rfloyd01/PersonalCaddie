var structfxls8962__control =
[
    [ "fastmode", "structfxls8962__control.html#a2028796efda87bc3c59fa6c18fb89460", null ],
    [ "le_be", "structfxls8962__control.html#a4f3d7a5eb3d1184a9ec12e5bf9af2a99", null ],
    [ "range", "structfxls8962__control.html#a9edcde0584b2ab6c4a7b49eaec49d237", null ],
    [ "reservered", "structfxls8962__control.html#a02615ef356d2cdd7e031a61eb421a51d", null ]
];