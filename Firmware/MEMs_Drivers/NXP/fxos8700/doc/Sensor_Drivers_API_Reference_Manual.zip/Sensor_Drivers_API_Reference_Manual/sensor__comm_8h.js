var sensor__comm_8h =
[
    [ "sensor_comm_handle", "structsensor__comm__handle.html", "structsensor__comm__handle" ],
    [ "sensor_comm_handle_t", "sensor__comm_8h.html#a9a8ec94fad416e6f0d4b0962fffb99f3", null ],
    [ "sensor_comm_init", "sensor__comm_8h.html#ac38df43878bd868f0f02c68cf63e08ba", null ],
    [ "sensor_comm_read", "sensor__comm_8h.html#a48d7d24503ebb8e67dd5aa1b60f57f13", null ],
    [ "sensor_comm_write", "sensor__comm_8h.html#ae2d462e046e28ca9bc3bfe00f4b86522", null ]
];