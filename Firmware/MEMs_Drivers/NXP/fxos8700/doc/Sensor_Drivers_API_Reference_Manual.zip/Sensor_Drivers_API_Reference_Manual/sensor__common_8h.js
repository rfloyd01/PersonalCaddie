var sensor__common_8h =
[
    [ "registerwritelist_t", "structregisterwritelist__t.html", "structregisterwritelist__t" ],
    [ "registerreadlist_t", "structregisterreadlist__t.html", "structregisterreadlist__t" ],
    [ "__END_READ_DATA__", "sensor__common_8h.html#aebb58a1bb3df30b7df4f6f14d0f1a81d", null ],
    [ "__END_WRITE_DATA__", "sensor__common_8h.html#a2cedde333a6373a3ee274bde6af145d0", null ],
    [ "NO_DATA_MASK", "sensor__common_8h.html#a54bc7936992590ffb530b3c9d29e2643", null ],
    [ "fxos8700_error_type_t", "sensor__common_8h.html#acbb6b9c8eec5ae730c90bd16cec67a8c", null ],
    [ "sensor_error_type", "sensor__common_8h.html#a362323763fffc45113e33ddbdb6eba34", [
      [ "SENSOR_SUCCESS", "sensor__common_8h.html#a362323763fffc45113e33ddbdb6eba34a6fe3474c6df06ef2bd1d3fb84fc57827", null ],
      [ "SENSOR_INVALIDPARAM_ERR", "sensor__common_8h.html#a362323763fffc45113e33ddbdb6eba34a22d20f4d5fbe564c0a8081654ea3fc60", null ],
      [ "SENSOR_INIT_ERR", "sensor__common_8h.html#a362323763fffc45113e33ddbdb6eba34abf4041c0ccb9a5facf5f16bda73bb5f7", null ],
      [ "SENSOR_WRITE_ERR", "sensor__common_8h.html#a362323763fffc45113e33ddbdb6eba34a614afdb046fd228696a8c2d697fa9ecb", null ],
      [ "SENSOR_READ_ERR", "sensor__common_8h.html#a362323763fffc45113e33ddbdb6eba34a41714ef48828326a94346bd416f87651", null ],
      [ "SENSOR_BAD_ADDRESS", "sensor__common_8h.html#a362323763fffc45113e33ddbdb6eba34a8c51bc5d8ac976682ab65bb2f1a3c381", null ]
    ] ],
    [ "sensor_burst_read", "sensor__common_8h.html#a5ce58c9313695dbc3be852e28587a32a", null ],
    [ "sensor_burst_write", "sensor__common_8h.html#aa29884fe9b1377bb16cf15a8958f4248", null ]
];