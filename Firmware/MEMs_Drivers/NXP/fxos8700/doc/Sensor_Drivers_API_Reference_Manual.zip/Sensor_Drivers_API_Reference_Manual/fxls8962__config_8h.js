var fxls8962__config_8h =
[
    [ "FIFO_SIZE", "fxls8962__config_8h.html#a6092455278a1ac67204e0dbe08f9d13f", null ],
    [ "gFxls8962EmbeddedFunctConfig", "fxls8962__config_8h.html#a8b32d800a4407164cadc6dbf12eaa96c", null ]
];