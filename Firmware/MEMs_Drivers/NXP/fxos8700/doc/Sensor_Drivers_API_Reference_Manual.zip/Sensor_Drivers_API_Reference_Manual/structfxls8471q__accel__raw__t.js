var structfxls8471q__accel__raw__t =
[
    [ "accel", "structfxls8471q__accel__raw__t.html#a58da43e0113e40372a9f0d23a600dc9d", null ]
];