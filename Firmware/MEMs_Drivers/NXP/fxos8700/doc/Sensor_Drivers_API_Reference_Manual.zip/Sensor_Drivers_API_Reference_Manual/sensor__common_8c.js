var sensor__common_8c =
[
    [ "sensor_burst_read", "sensor__common_8c.html#a5ce58c9313695dbc3be852e28587a32a", null ],
    [ "sensor_burst_write", "sensor__common_8c.html#aa29884fe9b1377bb16cf15a8958f4248", null ]
];