var structsensor__comm__handle =
[
    [ "parm", "structsensor__comm__handle.html#ae726254aa8b4d9048543f1e9b66293f4", null ],
    [ "pComm", "structsensor__comm__handle.html#a73a73fe0b894c933ec1a98e550e1e435", null ]
];