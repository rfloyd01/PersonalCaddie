var structregisterreadlist__t =
[
    [ "numBytes", "structregisterreadlist__t.html#a1440a8efa2f56cded09ced3ff687d32a", null ],
    [ "readFrom", "structregisterreadlist__t.html#a5fe82375de174c0511ca301fec78e441", null ]
];