var structfxos8700__driver =
[
    [ "pComHandle", "structfxos8700__driver.html#a8033da35191f015c060a9580d0929e7d", null ]
];