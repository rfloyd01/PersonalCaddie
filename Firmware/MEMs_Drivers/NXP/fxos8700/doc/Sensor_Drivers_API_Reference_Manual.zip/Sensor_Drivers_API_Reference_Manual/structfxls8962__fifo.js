var structfxls8962__fifo =
[
    [ "config1", "structfxls8962__fifo.html#a68f7c830f074616710c591dab49506eb", null ],
    [ "config2", "structfxls8962__fifo.html#a052f2decf7034f70b7f11d4434bf52a7", null ]
];