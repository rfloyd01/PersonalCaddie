var union_f_x_l_s8471_q___c_t_r_l___r_e_g5__t =
[
    [ "b", "union_f_x_l_s8471_q___c_t_r_l___r_e_g5__t.html#acf6a49f1726e3fead4972c18d4f77825", null ],
    [ "int_cfg_a_vecm", "union_f_x_l_s8471_q___c_t_r_l___r_e_g5__t.html#a693e644df9c84f347a4a8105b82a9dcc", null ],
    [ "int_cfg_aslp", "union_f_x_l_s8471_q___c_t_r_l___r_e_g5__t.html#aae7ddc49548f03ca81381e3337741362", null ],
    [ "int_cfg_drdy", "union_f_x_l_s8471_q___c_t_r_l___r_e_g5__t.html#a6ff9393e1291dd87ed17fe5b516e3602", null ],
    [ "int_cfg_ff_mt", "union_f_x_l_s8471_q___c_t_r_l___r_e_g5__t.html#ab4c1c5bcccd743dc7ed2433a9ae52841", null ],
    [ "int_cfg_fifo", "union_f_x_l_s8471_q___c_t_r_l___r_e_g5__t.html#ae05ca6df077d75b1f0e27a3528788da3", null ],
    [ "int_cfg_lndprt", "union_f_x_l_s8471_q___c_t_r_l___r_e_g5__t.html#a3389853fde79e84299e570be7b094184", null ],
    [ "int_cfg_pulse", "union_f_x_l_s8471_q___c_t_r_l___r_e_g5__t.html#a91396f8bf4304bfdb328b8985a1afc24", null ],
    [ "int_cfg_trans", "union_f_x_l_s8471_q___c_t_r_l___r_e_g5__t.html#a676cc62542877827a8941694563a2d44", null ],
    [ "w", "union_f_x_l_s8471_q___c_t_r_l___r_e_g5__t.html#aba9ed0487b0aa23eba534648df8384c0", null ]
];