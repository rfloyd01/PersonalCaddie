var union_f_x_l_s8471_q___p_l___s_t_a_t_u_s__t =
[
    [ "_reserved_", "union_f_x_l_s8471_q___p_l___s_t_a_t_u_s__t.html#ae5327d26267ececd72b1d5e3abd9a133", null ],
    [ "b", "union_f_x_l_s8471_q___p_l___s_t_a_t_u_s__t.html#add1e3823cc5e227486e34e07b00d77e3", null ],
    [ "bafro", "union_f_x_l_s8471_q___p_l___s_t_a_t_u_s__t.html#a11f7b02eff8094f44c5bfdedcd1834d1", null ],
    [ "lapo", "union_f_x_l_s8471_q___p_l___s_t_a_t_u_s__t.html#a8706bb8b6df817bf44ca5f226d95b6c3", null ],
    [ "lo", "union_f_x_l_s8471_q___p_l___s_t_a_t_u_s__t.html#a9d0956f4e4e86bda245a8a68c0086d9b", null ],
    [ "newlp", "union_f_x_l_s8471_q___p_l___s_t_a_t_u_s__t.html#a75fda6f706b71e0ca863c0ecec4d8d7b", null ],
    [ "w", "union_f_x_l_s8471_q___p_l___s_t_a_t_u_s__t.html#aba9ed0487b0aa23eba534648df8384c0", null ]
];