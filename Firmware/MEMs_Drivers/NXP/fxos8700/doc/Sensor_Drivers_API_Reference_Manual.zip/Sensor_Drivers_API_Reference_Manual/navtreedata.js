var NAVTREE =
[
  [ "Component Library:Sensor Drivers", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "Component Library-Sensor Drivers Interfaces", "md_generic_sensor_drivers_docs_apirm_docs_generator__sensor__driver__interfaces.html", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"fxls8471q__regdef_8h.html#a175d7074ef20a86941dbdbbc32dcc7bf",
"fxls8471q__regdef_8h.html#a6cc59ffba2c1fde05fed50862ef2e169",
"fxls8471q__regdef_8h.html#acf61343bb37a8ecdd6afda67ac8f90a1",
"fxls8962__regdef_8h.html#a0f33f58080557de677a6bf1073c61a41",
"fxls8962__regdef_8h.html#a758468b6add6ca96c69f970521db6960",
"fxls8962__regdef_8h.html#aec46d042752abf6234476b3c75198609",
"fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41ade3c704ef073dacd3d4a92afec78c920",
"fxos8700__regdef_8h.html#a2c9295f07ff27d08bc0fcca401ee9e8d",
"fxos8700__regdef_8h.html#a82fa9005309afbad9e6f44c21c81520e",
"fxos8700__regdef_8h.html#ade0ab7c7cfdc09678fbe722446e48f3d",
"mma865x__driver_8h.html#ad87005cdc21652ba698e1b497cbc8358a08e2886b3f835e73c8c8a079aae066c4",
"mma865x__regdef_8h.html#a4fcea1210bf2fc1a864a5913956cb20d",
"mma865x__regdef_8h.html#ad00835f7a963d714670addf4ae051bf3",
"union_f_x_l_s8471_q___a___f_f_m_t___t_h_s___y___m_s_b__t.html#aba9ed0487b0aa23eba534648df8384c0",
"union_f_x_l_s8471_q___t_r_a_n_s_i_e_n_t___s_r_c__t.html#a1964e3586d8d46baeeb6af28a1732ff2",
"union_f_x_o_s8700___a___f_f_m_t___t_h_s__t.html#a39a4a37449da55a6b8f4df0dc1027bce",
"union_f_x_o_s8700___o_u_t___y___m_s_b__t.html",
"union_m_m_a865x___p_l___s_t_a_t_u_s__t.html#a9d0956f4e4e86bda245a8a68c0086d9b"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';