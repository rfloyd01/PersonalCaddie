var structfxls8471q__interrupt__config =
[
    [ "control", "structfxls8471q__interrupt__config.html#aca255806c5902741c532a154a5bf6ee0", null ],
    [ "int1_2", "structfxls8471q__interrupt__config.html#abeeacb97fca61f282990594b2bbfae1f", null ],
    [ "intSources", "structfxls8471q__interrupt__config.html#acf2da1b28aa723b8d763a061d1d6f253", null ]
];