var mma865x__driver_8h =
[
    [ "mma865x_data_t", "structmma865x__data__t.html", "structmma865x__data__t" ],
    [ "mma865x_driver", "structmma865x__driver.html", "structmma865x__driver" ],
    [ "mma865x_interrupt_config", "structmma865x__interrupt__config.html", "structmma865x__interrupt__config" ],
    [ "MMA865x_ACCEL_8BITDATA_SIZE", "mma865x__driver_8h.html#a983c3193cea2592970593255dbf811e8", null ],
    [ "MMA865x_ACCEL_DATA_SIZE", "mma865x__driver_8h.html#a478eff258d7a1b494beb575ddcbd3527", null ],
    [ "NUM_AXES", "mma865x__driver_8h.html#a21adbd52ec4c70f91a0d0fc9c059b3b7", null ],
    [ "mma865x_config_type_t", "mma865x__driver_8h.html#ae150f5ebbc206c03d1903f548b3377ee", null ],
    [ "mma865x_data_type_t", "mma865x__driver_8h.html#a389335b6bf3360f9bbe5ffbb8a77d343", null ],
    [ "mma865x_driver_t", "mma865x__driver_8h.html#ac2c2c25d5d6b12bcba8ac5ea3270f50b", null ],
    [ "mma865x_embedded_func_config_type_t", "mma865x__driver_8h.html#a2d3e71f522a6abbf694f1db5b2fc1036", null ],
    [ "mma865x_event_status_type_t", "mma865x__driver_8h.html#a0bf39c32aebc5920c170067b596161bb", null ],
    [ "mma865x_event_type_t", "mma865x__driver_8h.html#a71f9a80f6e41a9337af128e81c8e089a", null ],
    [ "mma865x_interrupt_config_t", "mma865x__driver_8h.html#a5bee9aa008676c377efe79190832cdb8", null ],
    [ "mma865x_interrupt_source_t", "mma865x__driver_8h.html#af0241d7003558841050ce9d228e50df0", null ],
    [ "mma865x_mode_type_t", "mma865x__driver_8h.html#a025b76e352005b0c6e64560386cae710", null ],
    [ "mma865x_odr_t", "mma865x__driver_8h.html#adea3deccc3ed728971a25251c6d5c4ad", null ],
    [ "mma865x_power_mode_t", "mma865x__driver_8h.html#adda1246943a2295253e8f84c3de64ecc", null ],
    [ "mma865x_config_type", "mma865x__driver_8h.html#a5fa890b2c5ba59fb00ecdd0a2c954d89", [
      [ "MMA865x_ACCEL_8BIT_READ_POLL_MODE", "mma865x__driver_8h.html#a5fa890b2c5ba59fb00ecdd0a2c954d89a89daa90b9e683eceae722d3674ef8d10", null ],
      [ "MMA865x_ACCEL_14BIT_READ_POLL_MODE", "mma865x__driver_8h.html#a5fa890b2c5ba59fb00ecdd0a2c954d89ae75b1fa83e1db30ce81ebf987eb93ef9", null ],
      [ "MMA865x_ACCEL_14BIT_READ_FIFO_MODE", "mma865x__driver_8h.html#a5fa890b2c5ba59fb00ecdd0a2c954d89a90c7a6a841a735975da9cbe854892415", null ],
      [ "MMA865x_ACCEL_14BIT_READ_INT_MODE", "mma865x__driver_8h.html#a5fa890b2c5ba59fb00ecdd0a2c954d89a9c32dae67a481551b48d12ac72fe6a85", null ],
      [ "MMA865x_ACCEL_CONFIG_END", "mma865x__driver_8h.html#a5fa890b2c5ba59fb00ecdd0a2c954d89a00b2778524df21740d9a5c2cd2bec413", null ]
    ] ],
    [ "mma865x_data_type", "mma865x__driver_8h.html#ab50a886fb4c9b164bab27dfe7f747fbb", [
      [ "MMA865x_ACCEL_14BIT_DATAREAD", "mma865x__driver_8h.html#ab50a886fb4c9b164bab27dfe7f747fbbafa3e94fb65b686558e9017858dc8f0b0", null ],
      [ "MMA865x_ACCEL_14BIT_FIFO_DATAREAD", "mma865x__driver_8h.html#ab50a886fb4c9b164bab27dfe7f747fbbabe4a8a86e4d62157cd8c71f58161a4dc", null ],
      [ "MMA865x_ACCEL_8BIT_DATAREAD", "mma865x__driver_8h.html#ab50a886fb4c9b164bab27dfe7f747fbbaced8e95054210ea8ff4e864d75d99b3e", null ]
    ] ],
    [ "mma865x_embedded_func_config_type", "mma865x__driver_8h.html#af2673cac4cff00a00c825cf4bdcf7fea", [
      [ "MMA865x_AUTOWAKE_SLEEP", "mma865x__driver_8h.html#af2673cac4cff00a00c825cf4bdcf7feaa9bb64d1d40278fccc27e456cecc95d19", null ],
      [ "MMA865x_FREEFALL_DETECTION_MODE", "mma865x__driver_8h.html#af2673cac4cff00a00c825cf4bdcf7feaa4dd464dcba51f9c99404c9f9deea96a2", null ],
      [ "MMA865x_MOTION_DETECTION_MODE", "mma865x__driver_8h.html#af2673cac4cff00a00c825cf4bdcf7feaa52a761fb7be347136259a07399c26989", null ],
      [ "MMA865x_TRANSIENT_DETECTION_MODE", "mma865x__driver_8h.html#af2673cac4cff00a00c825cf4bdcf7feaa0eddc84cdb9852dd2ee2db4d1dcd9218", null ],
      [ "MMA865x_PULSE_DETECTION_MODE", "mma865x__driver_8h.html#af2673cac4cff00a00c825cf4bdcf7feaa68e842311fec37fb5db15fc76fdf595e", null ],
      [ "MMA865x_ORIENT_DETECTION_MODE", "mma865x__driver_8h.html#af2673cac4cff00a00c825cf4bdcf7feaa49a540a6196aceae63b7d61a87019c29", null ],
      [ "MMA865x_VM_DETECTION_MODE", "mma865x__driver_8h.html#af2673cac4cff00a00c825cf4bdcf7feaa113d67e80f5b6cfb048c4770e568b198", null ],
      [ "MMA865x_EMBEDDED_FUNCT_CONFIG_END", "mma865x__driver_8h.html#af2673cac4cff00a00c825cf4bdcf7feaaa6f99745c604e4a0ce8c9b2640dc0553", null ]
    ] ],
    [ "mma865x_event_status_type", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71", [
      [ "MMA865x_NO_EVENT_DETECTED", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71a89b399a7dd26b0d5813cef4edd63a1e1", null ],
      [ "MMA865x_FREEFALL_DETECTED", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71ae247d9d2070079d0b1a3f727ee08d4be", null ],
      [ "MMA865x_MOTION_DETECTED", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71a6b0c0027c1829e4cd63795c4ae513d69", null ],
      [ "MMA865x_TRANSIENT_DETECTED", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71a1f8853f4a2f8f8071234b0a3410c3d15", null ],
      [ "MMA865x_DOUBLETAP_DETECTED", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71a19afb814844b91fbb29ec4fd9fedddca", null ],
      [ "MMA865x_PORTRAIT_UP", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71a06d0b6cedeb685535a2b9dc5c970dbd3", null ],
      [ "MMA865x_PORTRAIT_DOWN", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71a0d834032622146002d4e3c649fc306b1", null ],
      [ "MMA865x_LANDSCAPE_RIGHT", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71aed160647509459556540a440154cb585", null ],
      [ "MMA865x_LANDSCAPE_LEFT", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71abfadf8a1b76871aa57358d980409419e", null ],
      [ "MMA865x_FRONT_SIDE", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71acb0a2a813dc48ea66143589319af6a6f", null ],
      [ "MMA865x_BACK_SIDE", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71ac5814411aacf522511ba544cfc05a2e6", null ],
      [ "MMA865x_ACCEL_VM_DETECTED", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71a2b2d647df7974f4e227ee3b37fe2b226", null ],
      [ "MMA865x_FIFO_WTRMRK_DETECTED", "mma865x__driver_8h.html#ae8ee529989ab2360a0657a7a0a47ec71a6e92ead1b4c89c97df1a89249eb8710a", null ]
    ] ],
    [ "mma865x_event_type", "mma865x__driver_8h.html#a7bbb2a163e15c1317e6ff2b59bd96d48", [
      [ "MMA865x_FREEFALL", "mma865x__driver_8h.html#a7bbb2a163e15c1317e6ff2b59bd96d48a0174e527a1aefecacb78706db0fea5e9", null ],
      [ "MMA865x_MOTION", "mma865x__driver_8h.html#a7bbb2a163e15c1317e6ff2b59bd96d48abc916a4a8b4d3a3899384b9ffe583609", null ],
      [ "MMA865x_TRANSIENT", "mma865x__driver_8h.html#a7bbb2a163e15c1317e6ff2b59bd96d48a316397e3c6ababa07f0ab53eae4b7807", null ],
      [ "MMA865x_DOUBLETAP", "mma865x__driver_8h.html#a7bbb2a163e15c1317e6ff2b59bd96d48af085c9d8dd8dad98378e8a82a37e0d97", null ],
      [ "MMA865x_ORIENTATION", "mma865x__driver_8h.html#a7bbb2a163e15c1317e6ff2b59bd96d48a3ca1119234f7941cefdca114a47f2113", null ],
      [ "MMA865x_VECTOR_MAGNITUDE", "mma865x__driver_8h.html#a7bbb2a163e15c1317e6ff2b59bd96d48ae976bc2bc77485d6383ddb71895c3401", null ]
    ] ],
    [ "mma865x_interrupt_source", "mma865x__driver_8h.html#a3969eb695dc119d2700937d3f60109dd", [
      [ "MMA865x_DRDY", "mma865x__driver_8h.html#a3969eb695dc119d2700937d3f60109dda24e18fc7cf60196827292f3c74f443a0", null ],
      [ "MMA865x_SRC_ASLP", "mma865x__driver_8h.html#a3969eb695dc119d2700937d3f60109dda2427d2ce8260e7bc36fb5a2c703f6ccf", null ],
      [ "MMA865x_SRC_FFMT", "mma865x__driver_8h.html#a3969eb695dc119d2700937d3f60109dda3224c05624c9fa99535e0069fb45fcae", null ],
      [ "MMA865x_SRC_PULSE", "mma865x__driver_8h.html#a3969eb695dc119d2700937d3f60109dda1a4a658e3b3d2cb546e6f611a0bf156b", null ],
      [ "MMA865x_SRC_LNDPRT", "mma865x__driver_8h.html#a3969eb695dc119d2700937d3f60109ddaa22d810e2bfaac5bface4a6b5c35ed94", null ],
      [ "MMA865x_SRC_TRANS", "mma865x__driver_8h.html#a3969eb695dc119d2700937d3f60109dda0f1501526b9a080ffc917ba98188468a", null ],
      [ "MMA865x_FIFO", "mma865x__driver_8h.html#a3969eb695dc119d2700937d3f60109dda3455e0a576845e79bfb8f4b53d9d04da", null ],
      [ "MMA865x_ASLP", "mma865x__driver_8h.html#a3969eb695dc119d2700937d3f60109dda0e52718b518d2c16eca58423e140d5e2", null ]
    ] ],
    [ "mma865x_mode_type", "mma865x__driver_8h.html#afad8d427abeefc36adeac3dcd52c2c15", [
      [ "MMA865x_STANDBY_MODE", "mma865x__driver_8h.html#afad8d427abeefc36adeac3dcd52c2c15a436aac14dc14fa73911a9ea1a173ac27", null ],
      [ "MMA865x_ACTIVE_MODE", "mma865x__driver_8h.html#afad8d427abeefc36adeac3dcd52c2c15accd7d1f26c5ad74b8716abecbc752c08", null ],
      [ "MMA865x_MODE_END", "mma865x__driver_8h.html#afad8d427abeefc36adeac3dcd52c2c15a9ea0c085fbe4d5ccd3b9e8d3b7f15c2d", null ]
    ] ],
    [ "mma865x_odr", "mma865x__driver_8h.html#a740c3c466d5b9b7a4c34d5e06e34079d", [
      [ "MMA865x_ODR_800_HZ", "mma865x__driver_8h.html#a740c3c466d5b9b7a4c34d5e06e34079dad02db34b55c7229d31bb44818be58b42", null ],
      [ "MMA865x_ODR_400_HZ", "mma865x__driver_8h.html#a740c3c466d5b9b7a4c34d5e06e34079da51c702325399f933fc04fbbb0c07570e", null ],
      [ "MMA865x_ODR_200_HZ", "mma865x__driver_8h.html#a740c3c466d5b9b7a4c34d5e06e34079daf2791b395daa59aacd9e96d13dffc9b2", null ],
      [ "MMA865x_ODR_100_HZ", "mma865x__driver_8h.html#a740c3c466d5b9b7a4c34d5e06e34079da1570870ea2393cf57f5e718a8376bd76", null ],
      [ "MMA865x_ODR_50_HZ", "mma865x__driver_8h.html#a740c3c466d5b9b7a4c34d5e06e34079dab60722c4f0ea082e77a510f051d66966", null ],
      [ "MMA865x_ODR_12P5_HZ", "mma865x__driver_8h.html#a740c3c466d5b9b7a4c34d5e06e34079daa71854272f24c97e8bc19cc5938730a3", null ],
      [ "MMA865x_ODR_6P25_HZ", "mma865x__driver_8h.html#a740c3c466d5b9b7a4c34d5e06e34079da97f28be7004f00fb7ef128692b35ca64", null ],
      [ "MMA865x_ODR_1P5625_HZ", "mma865x__driver_8h.html#a740c3c466d5b9b7a4c34d5e06e34079da878ea646325afebed0396b519ace3e96", null ]
    ] ],
    [ "mma865x_power_mode", "mma865x__driver_8h.html#ad87005cdc21652ba698e1b497cbc8358", [
      [ "MMA865x_ACCEL_NORMAL", "mma865x__driver_8h.html#ad87005cdc21652ba698e1b497cbc8358abf6e552e1215beb0963d6d53fe5be49f", null ],
      [ "MMA865x_ACCEL_LOWNOISE_LOWPOWER", "mma865x__driver_8h.html#ad87005cdc21652ba698e1b497cbc8358a221399a292335041a42303ed33a5e256", null ],
      [ "MMA865x_ACCEL_HIGHRESOLUTION", "mma865x__driver_8h.html#ad87005cdc21652ba698e1b497cbc8358afaf0a1d556adb246cf3ca0387fcdd273", null ],
      [ "MMA865x_ACCEL_LOWPOWER", "mma865x__driver_8h.html#ad87005cdc21652ba698e1b497cbc8358a08e2886b3f835e73c8c8a079aae066c4", null ]
    ] ],
    [ "mma865x_config_interrupt", "mma865x__driver_8h.html#a2c0871483bd0c0c757bbabd59ea057b3", null ],
    [ "mma865x_configure", "mma865x__driver_8h.html#a1a8fa2f726539f0669bb06f0288e156e", null ],
    [ "mma865x_deinit", "mma865x__driver_8h.html#adab1838ef4b7f5901274351c7a13dfa4", null ],
    [ "mma865x_disable_interrupt", "mma865x__driver_8h.html#a7e571d1f64004fca65c0e0cced88e6c9", null ],
    [ "mma865x_init", "mma865x__driver_8h.html#a1373405376836bd5202efb68f8e266fd", null ],
    [ "mma865x_read_data", "mma865x__driver_8h.html#afdac9f33379b54ab4e359fa5bd8f326d", null ],
    [ "mma865x_read_event", "mma865x__driver_8h.html#a47da68c140ac95a7623b4075c1ff4351", null ],
    [ "mma865x_read_reg", "mma865x__driver_8h.html#a83e99616355e4f7dc67184ac87e6daf5", null ],
    [ "mma865x_set_embedded_function", "mma865x__driver_8h.html#a0659d348fd8814e3ae6c5eb71ed4f025", null ],
    [ "mma865x_write_reg", "mma865x__driver_8h.html#ad8ad98f54d4b6068756a19a3bddc0fab", null ]
];