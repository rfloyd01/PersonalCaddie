var fxls8471q__driver_8c =
[
    [ "fxls8471q_mode_t", "fxls8471q__driver_8c.html#a7271ccec7b8b971562836039df685715", null ],
    [ "fxls8471q_mode", "fxls8471q__driver_8c.html#a610f8aab050cadb242496e05c6b8cce9", [
      [ "STANDBY", "fxls8471q__driver_8c.html#a610f8aab050cadb242496e05c6b8cce9ae4634ae4352b512b38c5da9dc1610ca6", null ],
      [ "ACTIVE", "fxls8471q__driver_8c.html#a610f8aab050cadb242496e05c6b8cce9a33cf1d8ef1d06ee698a7fabf40eb3a7f", null ]
    ] ],
    [ "fxls8471q_config_interrupt", "fxls8471q__driver_8c.html#ad759a935bd465b960af5bd70c2c8ad3f", null ],
    [ "fxls8471q_configure_accel", "fxls8471q__driver_8c.html#a0f7a2ca4a6ca025681cbf276ce3631eb", null ],
    [ "fxls8471q_disable_interrupt", "fxls8471q__driver_8c.html#aeb391e56470f37b512ab346ce3799489", null ],
    [ "fxls8471q_init", "fxls8471q__driver_8c.html#a4a4793c56b09dff8f16940629753fa95", null ],
    [ "fxls8471q_read_accel_raw", "fxls8471q__driver_8c.html#ad306297cfa129e95db5d25dbbea2f12f", null ],
    [ "fxls8471q_read_event", "fxls8471q__driver_8c.html#a6e9d146895bd968cee248644b08a8c5b", null ],
    [ "fxls8471q_read_reg", "fxls8471q__driver_8c.html#a784818424fbf2a7b8a8490b731e36ec6", null ],
    [ "fxls8471q_set_embedded_function", "fxls8471q__driver_8c.html#a40bd1a9bb97e453e4ec1849eed9fc9a2", null ],
    [ "fxls8471q_write_reg", "fxls8471q__driver_8c.html#a58cff1803bbda6a5afd5aaa57fc6cd3d", null ],
    [ "set_mode", "fxls8471q__driver_8c.html#acaeeea89dbbaa4eb492cd08c876ba8aa", null ],
    [ "sEvent", "fxls8471q__driver_8c.html#ae8dd33086047ad01755f97a2e066c6ad", null ]
];