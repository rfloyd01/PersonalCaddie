var structmma865x__driver =
[
    [ "pComHandle", "structmma865x__driver.html#a8033da35191f015c060a9580d0929e7d", null ]
];