var structfxls8471q__control =
[
    [ "cutOffFrequency", "structfxls8471q__control.html#a60808fa77e0636bb4540f5cc5a365726", null ],
    [ "fastmode", "structfxls8471q__control.html#a2028796efda87bc3c59fa6c18fb89460", null ],
    [ "highpassFilter", "structfxls8471q__control.html#aa8b49f4d0100fad70e295f8ad509568e", null ],
    [ "range", "structfxls8471q__control.html#a9edcde0584b2ab6c4a7b49eaec49d237", null ],
    [ "reservered", "structfxls8471q__control.html#a02615ef356d2cdd7e031a61eb421a51d", null ]
];