var structmma865x__interrupt__config =
[
    [ "int1_2", "structmma865x__interrupt__config.html#a8b9fd2bc6ab79011cf8726096c100d27", null ],
    [ "intSources", "structmma865x__interrupt__config.html#a7003067806366dbc9d3d0a6b856f0a5d", null ],
    [ "ipol", "structmma865x__interrupt__config.html#a107705cb4eae0abdc8c1b721d79ae772", null ],
    [ "pp_od", "structmma865x__interrupt__config.html#a14c3cfd5ae0507456f4bc0d9ce424dfb", null ],
    [ "reserved", "structmma865x__interrupt__config.html#acb7bc06bed6f6408d719334fc41698c7", null ]
];