var globals_eval =
[
    [ "a", "globals_eval.html", null ],
    [ "f", "globals_eval_f.html", null ],
    [ "m", "globals_eval_m.html", null ],
    [ "s", "globals_eval_s.html", null ]
];