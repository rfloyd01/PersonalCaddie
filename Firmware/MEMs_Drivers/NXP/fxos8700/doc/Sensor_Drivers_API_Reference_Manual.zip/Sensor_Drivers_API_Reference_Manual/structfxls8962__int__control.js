var structfxls8962__int__control =
[
    [ "ipol", "structfxls8962__int__control.html#a107705cb4eae0abdc8c1b721d79ae772", null ],
    [ "pp_od", "structfxls8962__int__control.html#a14c3cfd5ae0507456f4bc0d9ce424dfb", null ],
    [ "reserved", "structfxls8962__int__control.html#acb7bc06bed6f6408d719334fc41698c7", null ]
];