var sensor__comm_8c =
[
    [ "sensor_comm_init", "sensor__comm_8c.html#ac38df43878bd868f0f02c68cf63e08ba", null ],
    [ "sensor_comm_read", "sensor__comm_8c.html#a48d7d24503ebb8e67dd5aa1b60f57f13", null ],
    [ "sensor_comm_write", "sensor__comm_8c.html#ae2d462e046e28ca9bc3bfe00f4b86522", null ]
];