var structfxls8471q__fifo =
[
    [ "fifo_mode", "structfxls8471q__fifo.html#a54018efdf39077570ac2e84a11d4eaf0", null ],
    [ "watermark", "structfxls8471q__fifo.html#a3585201b190b39d2d702daa9192323a3", null ]
];