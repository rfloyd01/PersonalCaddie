var structfxls8962__interrupt__config =
[
    [ "control", "structfxls8962__interrupt__config.html#a6bb4787b17c7194504c81e33916054f8", null ],
    [ "int1_2", "structfxls8962__interrupt__config.html#a648a3fee64f28782ed8134c03ca65dbb", null ],
    [ "intSources", "structfxls8962__interrupt__config.html#a05aaaedc7acb85701a4d0be4c7c64344", null ]
];