var fxls8471q__config_8h =
[
    [ "FIFO_SIZE", "fxls8471q__config_8h.html#a6092455278a1ac67204e0dbe08f9d13f", null ],
    [ "gFxls8471EmbeddedFunctConfig", "fxls8471q__config_8h.html#a347630f7732583e2d8f510ba5d433d2b", null ]
];