var fxos8700__driver_8h =
[
    [ "fxos8700_data_t", "structfxos8700__data__t.html", "structfxos8700__data__t" ],
    [ "fxos8700_driver", "structfxos8700__driver.html", "structfxos8700__driver" ],
    [ "fxos8700_interrupt_config", "structfxos8700__interrupt__config.html", "structfxos8700__interrupt__config" ],
    [ "FXOS8700_ACCEL_8BITDATA_SIZE", "fxos8700__driver_8h.html#ae0462fd519a9827ffcde2ac05f12c7d5", null ],
    [ "FXOS8700_ACCEL_DATA_SIZE", "fxos8700__driver_8h.html#ac565dfc6599c537d2df6f1923b285f1e", null ],
    [ "FXOS8700_ACCEL_MAG_DATA_SIZE", "fxos8700__driver_8h.html#ab7af0b221d5c7397fd6c95d9fa6b57cd", null ],
    [ "FXOS8700_MAG_DATA_SIZE", "fxos8700__driver_8h.html#a262b947c4b212185d30a50993e503b8f", null ],
    [ "NUM_AXES", "fxos8700__driver_8h.html#a21adbd52ec4c70f91a0d0fc9c059b3b7", null ],
    [ "fxos8700_accel_config_type_t", "fxos8700__driver_8h.html#ad5a90bafcb680b4780f59e20fca526a3", null ],
    [ "fxos8700_data_type_t", "fxos8700__driver_8h.html#a9681b6c1072ca932d5bd0e64981d78a1", null ],
    [ "fxos8700_driver_t", "fxos8700__driver_8h.html#a81204599f01048ffb608840f5036c2e5", null ],
    [ "fxos8700_embedded_func_config_type_t", "fxos8700__driver_8h.html#aa1d5628055c97d1b9b3ee89d2ad729e9", null ],
    [ "fxos8700_event_status_type_t", "fxos8700__driver_8h.html#a9ab332cacc3646e7a511f4acf4dea23f", null ],
    [ "fxos8700_event_type_t", "fxos8700__driver_8h.html#a9f56a2674cfbcf79270b2d5a86278ecb", null ],
    [ "fxos8700_hybrid_config_type_t", "fxos8700__driver_8h.html#a1e1ee9c9f63f618feba51eecc1363f37", null ],
    [ "fxos8700_hybrid_odr_t", "fxos8700__driver_8h.html#af04f6372486947b4b37abb3a3ffe958f", null ],
    [ "fxos8700_interrupt_config_t", "fxos8700__driver_8h.html#a1f5a9480f907187c54dac48605ee62b2", null ],
    [ "fxos8700_interrupt_source_t", "fxos8700__driver_8h.html#aa108d4016ee1ea8545608a1d36b941e1", null ],
    [ "fxos8700_mag_config_type_t", "fxos8700__driver_8h.html#a9e5d462b8f7fcbb0d76d14413b5043ff", null ],
    [ "fxos8700_mode_type_t", "fxos8700__driver_8h.html#a0f9903ca951d2e2e4306983091fb6287", null ],
    [ "fxos8700_odr_t", "fxos8700__driver_8h.html#aaa15913d4a414fb082a24f6e9de508b4", null ],
    [ "fxos8700_power_mode_t", "fxos8700__driver_8h.html#a8fe7cc4c9d9e48d2e4696f525d4fd9c8", null ],
    [ "fxos8700_accel_config_type", "fxos8700__driver_8h.html#aa94cdf46305f186e7b783cd7c657dd06", [
      [ "FXOS8700_ACCEL_8BIT_READ_POLL_MODE", "fxos8700__driver_8h.html#aa94cdf46305f186e7b783cd7c657dd06a363bad5795d666d86532022c0346744d", null ],
      [ "FXOS8700_ACCEL_14BIT_READ_POLL_MODE", "fxos8700__driver_8h.html#aa94cdf46305f186e7b783cd7c657dd06ac5b7b3e2425a5665822dc36e32263ffc", null ],
      [ "FXOS8700_ACCEL_14BIT_READ_FIFO_MODE", "fxos8700__driver_8h.html#aa94cdf46305f186e7b783cd7c657dd06a2ade96f29d22332480f1a8208b45da23", null ],
      [ "FXOS8700_ACCEL_14BIT_READ_INT_MODE", "fxos8700__driver_8h.html#aa94cdf46305f186e7b783cd7c657dd06a2afa58158ad2cd93cc878a3700cb8865", null ],
      [ "FXOS8700_ACCEL_CONFIG_END", "fxos8700__driver_8h.html#aa94cdf46305f186e7b783cd7c657dd06a2a1c6bdb4a159b7ee3249be4001be124", null ]
    ] ],
    [ "fxos8700_data_type", "fxos8700__driver_8h.html#a1a46c5ec28c27d384f522e064a4307eb", [
      [ "FXOS8700_ACCEL_14BIT_DATAREAD", "fxos8700__driver_8h.html#a1a46c5ec28c27d384f522e064a4307eba9c5ddaf1cb274f5fdbc14b8394f0c5e7", null ],
      [ "FXOS8700_ACCEL_14BIT_FIFO_DATAREAD", "fxos8700__driver_8h.html#a1a46c5ec28c27d384f522e064a4307ebac671d81c1377f5292564079389698b03", null ],
      [ "FXOS8700_ACCEL_8BIT_DATAREAD", "fxos8700__driver_8h.html#a1a46c5ec28c27d384f522e064a4307eba9061359db5c7dbad99c7e79ec9e56656", null ],
      [ "FXOS8700_ACCEL_MAG_HYBRID", "fxos8700__driver_8h.html#a1a46c5ec28c27d384f522e064a4307eba68b149a6c5a30f705569911e78deebd6", null ],
      [ "FXOS8700_MAG_DATAREAD", "fxos8700__driver_8h.html#a1a46c5ec28c27d384f522e064a4307eba02e1b35fe4b7b3e1e196b1345be1893f", null ]
    ] ],
    [ "fxos8700_embedded_func_config_type", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129", [
      [ "FXOS8700_AUTOWAKE_SLEEP", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129a2414614677a59882f0b20890e20b680f", null ],
      [ "FXOS8700_FREEFALL_DETECTION_MODE", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129ade41d8aaa1df366d0dcc123875163523", null ],
      [ "FXOS8700_MOTION_DETECTION_MODE", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129ab09b24d00dc634c3bdb7625152fbc361", null ],
      [ "FXOS8700_TRANSIENT_DETECTION_MODE", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129aa38bc1ac721ead8db1808adc42f78631", null ],
      [ "FXOS8700_PULSE_DETECTION_MODE", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129a5a6847eba69985589bd98b590b3c0881", null ],
      [ "FXOS8700_ORIENT_DETECTION_MODE", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129aaa14f83f00ac12eab909a4a7cd586549", null ],
      [ "FXOS8700_ACCEL_VM_DETECTION_MODE", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129a577d16dc4459be195d0210c1577347a2", null ],
      [ "FXOS8700_MAG_VM_DETECTION_MODE", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129a38f376a4304fffaf240941dd66f6aa05", null ],
      [ "FXOS8700_MAG_THS_DETECTION_MODE", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129af660d36c1cf09998dd2da13863f993de", null ],
      [ "FXOS8700_MAG_MINMAX_DETECTION_MODE", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129a4f12ccf9e9d187a2046b466e93c80cb1", null ],
      [ "FXOS8700_EMBEDDED_FUNCT_CONFIG_END", "fxos8700__driver_8h.html#a8109f0894d05159448e50a7a4fc86129a1afe0b2ec4a483041bf68bfaf607df8b", null ]
    ] ],
    [ "fxos8700_event_status_type", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41", [
      [ "FXOS8700_NO_EVENT_DETECTED", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41a3af5d374e7cb9fbe9028d05c807584c5", null ],
      [ "FXOS8700_FREEFALL_DETECTED", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41a15dd93f2b14f31da66de4c9432aa974d", null ],
      [ "FXOS8700_MOTION_DETECTED", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41a7c885b7701bb7d70d7b333c1480864e7", null ],
      [ "FXOS8700_TRANSIENT_DETECTED", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41ae149fd8d76b26a002807f1e9599eeac2", null ],
      [ "FXOS8700_DOUBLETAP_DETECTED", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41ab22f4fcca730316c9df69f82361ce9ba", null ],
      [ "FXOS8700_PORTRAIT_UP", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41acc007e1f95359457b34a71eb2a30676c", null ],
      [ "FXOS8700_PORTRAIT_DOWN", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41a27c5e0d87163842ce398a00f98adf572", null ],
      [ "FXOS8700_LANDSCAPE_RIGHT", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41ab603447f2ae91eadd13044dbdd204bd0", null ],
      [ "FXOS8700_LANDSCAPE_LEFT", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41add060645d548e95fae251e22dcbb1d83", null ],
      [ "FXOS8700_FRONT_SIDE", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41a73843b6968781db800f749585cabc3fb", null ],
      [ "FXOS8700_BACK_SIDE", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41a152be39870a564032795823d1c8b78ea", null ],
      [ "FXOS8700_ACCEL_VM_DETECTED", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41abaa481e523f5246a5bb118bb8a928729", null ],
      [ "FXOS8700_MAG_VM_DETECTED", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41ade3c704ef073dacd3d4a92afec78c920", null ],
      [ "FXOS8700_MAG_THS_DETECTED", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41a4d8b4187ee82a14f3d21359eb0bc1d32", null ],
      [ "FXOS8700_MAG_MIN_DETECTED", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41ad6a3ac3f64aed2728024266810e64552", null ],
      [ "FXOS8700_MAG_MAX_DETECTED", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41a32e337db98cf9c5d1673abd0b726f472", null ],
      [ "FXOS8700_FIFO_WTRMRK_DETECTED", "fxos8700__driver_8h.html#afa03c74b17ee8bc985abac8aff890b41adff2f1987fd4d4ddb00dd5622367e7f8", null ]
    ] ],
    [ "fxos8700_event_type", "fxos8700__driver_8h.html#a353cea63457ba103c508049d14a27ddd", [
      [ "FXOS8700_FREEFALL", "fxos8700__driver_8h.html#a353cea63457ba103c508049d14a27dddae785e9df35ad192dd975ed67243c7073", null ],
      [ "FXOS8700_MOTION", "fxos8700__driver_8h.html#a353cea63457ba103c508049d14a27dddac98ff66894351c8a100ede69f74b65f5", null ],
      [ "FXOS8700_TRANSIENT", "fxos8700__driver_8h.html#a353cea63457ba103c508049d14a27dddabbe4f1ca7b1d93eb4d30b843fbfb1219", null ],
      [ "FXOS8700_DOUBLETAP", "fxos8700__driver_8h.html#a353cea63457ba103c508049d14a27ddda7a9d24fe58c752ec9f4b858046f4036e", null ],
      [ "FXOS8700_ORIENTATION", "fxos8700__driver_8h.html#a353cea63457ba103c508049d14a27ddda42642d4ae203681bfa0bfe5503b777b0", null ],
      [ "FXOS8700_ACCEL_VECTOR_MAGNITUDE", "fxos8700__driver_8h.html#a353cea63457ba103c508049d14a27ddda0d7e37d95acee22bc23f9ed618da967e", null ],
      [ "FXOS8700_MAG_VECTOR_MAGNITUDE", "fxos8700__driver_8h.html#a353cea63457ba103c508049d14a27ddda59ce09b58219fb444cd92133b443a866", null ],
      [ "FXOS8700_MAG_THRESHOLD", "fxos8700__driver_8h.html#a353cea63457ba103c508049d14a27dddab00beb1ff80f0ea39801b569e05b8f23", null ],
      [ "FXOS8700_MAG_MINMAX", "fxos8700__driver_8h.html#a353cea63457ba103c508049d14a27dddaa70fdc25571e520a6eb833db3c280c60", null ]
    ] ],
    [ "fxos8700_hybrid_config_type", "fxos8700__driver_8h.html#a1822613f558ed4ed1010ebb5a0d794e9", [
      [ "FXOS8700_HYBRID_READ_POLL_MODE", "fxos8700__driver_8h.html#a1822613f558ed4ed1010ebb5a0d794e9a22cd57aab7c39b1e5394d5bc1692f88a", null ],
      [ "FXOS8700_HYBRID_READ_INT_MODE", "fxos8700__driver_8h.html#a1822613f558ed4ed1010ebb5a0d794e9a80f5e4745e4a3344f0e56904e745f2c8", null ],
      [ "FXOS8700_HYBRID_CONFIG_END", "fxos8700__driver_8h.html#a1822613f558ed4ed1010ebb5a0d794e9a3f24157f0d40c57ae971687948d72e54", null ]
    ] ],
    [ "fxos8700_hybrid_odr", "fxos8700__driver_8h.html#ad602d037ad11eb08ab7819ccd8887eca", [
      [ "FXOS8700_ODR_HYBRID_400_HZ", "fxos8700__driver_8h.html#ad602d037ad11eb08ab7819ccd8887ecaa2a6d68102e795b7aefa11a76cda49364", null ],
      [ "FXOS8700_ODR_HYBRID_200_HZ", "fxos8700__driver_8h.html#ad602d037ad11eb08ab7819ccd8887ecaa08b520a3e4f6f528103e88f874076416", null ],
      [ "FXOS8700_ODR_HYBRID_100_HZ", "fxos8700__driver_8h.html#ad602d037ad11eb08ab7819ccd8887ecaad8905c839eb32148a4ec3b7b3f89e4df", null ],
      [ "FXOS8700_ODR_HYBRID_50_HZ", "fxos8700__driver_8h.html#ad602d037ad11eb08ab7819ccd8887ecaa53ebaa261a7f3e7e441ed7dc414bb7e5", null ],
      [ "FXOS8700_ODR_HYBRID_25_HZ", "fxos8700__driver_8h.html#ad602d037ad11eb08ab7819ccd8887ecaa277b3b5e734aa04eb1bd850d7997977e", null ],
      [ "FXOS8700_ODR_HYBRID_6P25_HZ", "fxos8700__driver_8h.html#ad602d037ad11eb08ab7819ccd8887ecaac4ec98552d000f79bc4eaa2cf97eef03", null ],
      [ "FXOS8700_ODR_HYBRID_3P125_HZ", "fxos8700__driver_8h.html#ad602d037ad11eb08ab7819ccd8887ecaa5ef8753d30d5febacc1dc99894812553", null ],
      [ "FXOS8700_ODR_HYBRID_0P7813_HZ", "fxos8700__driver_8h.html#ad602d037ad11eb08ab7819ccd8887ecaa4b3129950f27770e42f12e18d18c6c2a", null ]
    ] ],
    [ "fxos8700_interrupt_source", "fxos8700__driver_8h.html#a4b365b23d0c3595381da307567a1ceed", [
      [ "FXOS8700_DRDY", "fxos8700__driver_8h.html#a4b365b23d0c3595381da307567a1ceedac5318ada9e5c0bc9f4a33fdc2e6a4cd3", null ],
      [ "FXOS8700_SRC_ASLP", "fxos8700__driver_8h.html#a4b365b23d0c3595381da307567a1ceedaf8bbb4caa4a1e19d6d73fe8605a17272", null ],
      [ "FXOS8700_SRC_FFMT", "fxos8700__driver_8h.html#a4b365b23d0c3595381da307567a1ceeda60c3e4aeae965524dedf1342b2b16def", null ],
      [ "FXOS8700_SRC_PULSE", "fxos8700__driver_8h.html#a4b365b23d0c3595381da307567a1ceeda709ba96708f70cf0264c23a695381124", null ],
      [ "FXOS8700_SRC_LNDPRT", "fxos8700__driver_8h.html#a4b365b23d0c3595381da307567a1ceeda6ddd3f1c41aeef0a6166ba4d4908836c", null ],
      [ "FXOS8700_SRC_TRANS", "fxos8700__driver_8h.html#a4b365b23d0c3595381da307567a1ceeda4fc02153fdf0a24e8163458f84f05c9c", null ],
      [ "FXOS8700_FIFO", "fxos8700__driver_8h.html#a4b365b23d0c3595381da307567a1ceeda93d751cdf3f9088e16e9f9aa86d52d9c", null ],
      [ "FXOS8700_ASLP", "fxos8700__driver_8h.html#a4b365b23d0c3595381da307567a1ceeda918636e0f79d3a3d22a2fa21dcbc282a", null ]
    ] ],
    [ "fxos8700_mag_config_type", "fxos8700__driver_8h.html#ad307a00787111f1386128398a86c14ae", [
      [ "FXOS8700_MAG_READ_POLLING_MODE", "fxos8700__driver_8h.html#ad307a00787111f1386128398a86c14aea2b10bdf17f11a7263dd1e0d74412bb5c", null ],
      [ "FXOS8700_MAG_READ_INT_MODE", "fxos8700__driver_8h.html#ad307a00787111f1386128398a86c14aea11cb0c34e50e0d5b154d8723edb933d7", null ]
    ] ],
    [ "fxos8700_mode_type", "fxos8700__driver_8h.html#aca0b16d87247351948c23d45be444b4f", [
      [ "FXOS8700_STANDBY_MODE", "fxos8700__driver_8h.html#aca0b16d87247351948c23d45be444b4fa41ba09669d45e8d12ebd25bf53583919", null ],
      [ "FXOS8700_ACTIVE_MODE", "fxos8700__driver_8h.html#aca0b16d87247351948c23d45be444b4fa0a474ec6ebb5ecc0c036631c6c6c6665", null ],
      [ "FXOS8700_MODE_END", "fxos8700__driver_8h.html#aca0b16d87247351948c23d45be444b4fa044a25eac1932f567edc99a5d7790a04", null ]
    ] ],
    [ "fxos8700_odr", "fxos8700__driver_8h.html#aad577a6c08a6b14f76f8524b35c5f21b", [
      [ "FXOS8700_ODR_SINGLE_800_HZ", "fxos8700__driver_8h.html#aad577a6c08a6b14f76f8524b35c5f21ba10826ff7e51a3d20520b40056521ff5a", null ],
      [ "FXOS8700_ODR_SINGLE_400_HZ", "fxos8700__driver_8h.html#aad577a6c08a6b14f76f8524b35c5f21baf67e0eab01bd2c1e86389e0243e01c50", null ],
      [ "FXOS8700_ODR_SINGLE_200_HZ", "fxos8700__driver_8h.html#aad577a6c08a6b14f76f8524b35c5f21ba6bec69684de5b5dfe68c936b0df93f37", null ],
      [ "FXOS8700_ODR_SINGLE_100_HZ", "fxos8700__driver_8h.html#aad577a6c08a6b14f76f8524b35c5f21ba055e8ae6375096c13af0b6bfe44e3763", null ],
      [ "FXOS8700_ODR_SINGLE_50_HZ", "fxos8700__driver_8h.html#aad577a6c08a6b14f76f8524b35c5f21bae07e59a03939f689b9ea312ca2bc6206", null ],
      [ "FXOS8700_ODR_SINGLE_12P5_HZ", "fxos8700__driver_8h.html#aad577a6c08a6b14f76f8524b35c5f21ba604808b0312455091e4f6eda8f4fcf0b", null ],
      [ "FXOS8700_ODR_SINGLE_6P25_HZ", "fxos8700__driver_8h.html#aad577a6c08a6b14f76f8524b35c5f21ba756f2599533054ac907807fe5ff23f32", null ],
      [ "FXOS8700_ODR_SINGLE_1P5625_HZ", "fxos8700__driver_8h.html#aad577a6c08a6b14f76f8524b35c5f21ba832ec9351470f80cd8373ae578d1d263", null ]
    ] ],
    [ "fxos8700_power_mode", "fxos8700__driver_8h.html#a420bddb76d8b14c72c694ed7e04b2cb4", [
      [ "FXOS8700_ACCEL_NORMAL", "fxos8700__driver_8h.html#a420bddb76d8b14c72c694ed7e04b2cb4a38f3e5deb429316525df396cb8650e95", null ],
      [ "FXOS8700_ACCEL_LOWNOISE_LOWPOWER", "fxos8700__driver_8h.html#a420bddb76d8b14c72c694ed7e04b2cb4a36c22cbfd22a3d41dc3ae295209f2278", null ],
      [ "FXOS8700_ACCEL_HIGHRESOLUTION", "fxos8700__driver_8h.html#a420bddb76d8b14c72c694ed7e04b2cb4a9c0f693110ddc716b530c3a09a4b938e", null ],
      [ "FXOS8700_ACCEL_LOWPOWER", "fxos8700__driver_8h.html#a420bddb76d8b14c72c694ed7e04b2cb4a4e78eccdf398bd62c01236bfc886d4e3", null ]
    ] ],
    [ "fxos8700_config_interrupt", "fxos8700__driver_8h.html#a9e3597292a03e576d6de2f1161add480", null ],
    [ "fxos8700_configure_accel", "fxos8700__driver_8h.html#ad5179ab17b549e9718d272c6e3e5f864", null ],
    [ "fxos8700_configure_hybrid", "fxos8700__driver_8h.html#a9f238e5f231fd6c21b4f63a3e79b2039", null ],
    [ "fxos8700_configure_mag", "fxos8700__driver_8h.html#a2f4f309eec82f076026480fc28d6e0e6", null ],
    [ "fxos8700_deinit", "fxos8700__driver_8h.html#a6f9872b3dc335763155a5da5d37e3afc", null ],
    [ "fxos8700_disable_interrupt", "fxos8700__driver_8h.html#adec75586d8eb40e640ec1b632a2dacfe", null ],
    [ "fxos8700_init", "fxos8700__driver_8h.html#a1acb70a9939b17fc50d5a83f6f300531", null ],
    [ "fxos8700_read_data", "fxos8700__driver_8h.html#aac6504a8509c9962a0a2104242f44ad7", null ],
    [ "fxos8700_read_event", "fxos8700__driver_8h.html#a870b6f3124f13f7ef7269ab701e4ca1a", null ],
    [ "fxos8700_read_reg", "fxos8700__driver_8h.html#aeb12154a2ab4702851c581b7eb801666", null ],
    [ "fxos8700_set_embedded_function", "fxos8700__driver_8h.html#acee78390a76d65b7cc8d1ef5474b321b", null ],
    [ "fxos8700_write_reg", "fxos8700__driver_8h.html#ae0022576b00a2accfc416fa94115d996", null ]
];