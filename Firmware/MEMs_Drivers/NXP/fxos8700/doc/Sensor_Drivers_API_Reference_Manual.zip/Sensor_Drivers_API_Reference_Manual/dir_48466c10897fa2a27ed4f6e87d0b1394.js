var dir_48466c10897fa2a27ed4f6e87d0b1394 =
[
    [ "fxls8471q_config.c", "fxls8471q__config_8c.html", "fxls8471q__config_8c" ],
    [ "fxls8471q_config.h", "fxls8471q__config_8h.html", "fxls8471q__config_8h" ],
    [ "fxls8471q_driver.c", "fxls8471q__driver_8c.html", "fxls8471q__driver_8c" ],
    [ "fxls8471q_driver.h", "fxls8471q__driver_8h.html", "fxls8471q__driver_8h" ],
    [ "fxls8471q_regdef.h", "fxls8471q__regdef_8h.html", "fxls8471q__regdef_8h" ]
];