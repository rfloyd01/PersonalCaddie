var structregisterwritelist__t =
[
    [ "mask", "structregisterwritelist__t.html#a8a74907784be6c7786c2d060c8d7e10b", null ],
    [ "value", "structregisterwritelist__t.html#a638e4503e0ae6ce655b7ad2e17e8f0ad", null ],
    [ "writeTo", "structregisterwritelist__t.html#a8f4ad863f28f32ae52b7c97ff42bf921", null ]
];