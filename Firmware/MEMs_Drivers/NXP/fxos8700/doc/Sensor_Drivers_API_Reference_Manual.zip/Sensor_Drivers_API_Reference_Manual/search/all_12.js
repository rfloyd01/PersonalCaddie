var searchData=
[
  ['value',['value',['../structregisterwritelist__t.html#a638e4503e0ae6ce655b7ad2e17e8f0ad',1,'registerwritelist_t']]],
  ['vecm_5fcnt',['VECM_CNT',['../fxls8471q__config_8c.html#a9edd0523cb5c5a084e31dae53aebc682',1,'fxls8471q_config.c']]],
  ['vecm_5fen',['vecm_en',['../union_f_x_l_s8962___s_e_n_s___c_o_n_f_i_g5__t.html#abd9f848d3696322994918778bcb7f52c',1,'FXLS8962_SENS_CONFIG5_t']]],
  ['vecm_5finit_5fref_5foneig',['VECM_INIT_REF_ONEIG',['../fxls8471q__config_8c.html#a381f4066b9b5b064203ad8f8884ca001',1,'fxls8471q_config.c']]],
  ['vecm_5finit_5fref_5fzero',['VECM_INIT_REF_ZERO',['../fxls8471q__config_8c.html#afbdf02d74d15f03afad2195a502daaf9',1,'fxls8471q_config.c']]],
  ['vecm_5fths_5flsb',['VECM_THS_LSB',['../fxls8471q__config_8c.html#a15dd5d3284f1feeddcac35833b5dca28',1,'fxls8471q_config.c']]],
  ['vecm_5fths_5fmsb',['VECM_THS_MSB',['../fxls8471q__config_8c.html#a52464cb70da483d3b0de4a3f04ade543',1,'fxls8471q_config.c']]]
];
