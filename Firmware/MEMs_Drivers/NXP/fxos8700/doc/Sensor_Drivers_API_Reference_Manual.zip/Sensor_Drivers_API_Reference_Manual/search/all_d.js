var searchData=
[
  ['oae',['oae',['../union_f_x_o_s8700___a___f_f_m_t___c_f_g__t.html#a6aba76c05822dc7222fc2c103861fa59',1,'FXOS8700_A_FFMT_CFG_t::oae()'],['../union_f_x_l_s8471_q___a___f_f_m_t___c_f_g__t.html#a6aba76c05822dc7222fc2c103861fa59',1,'FXLS8471Q_A_FFMT_CFG_t::oae()'],['../union_m_m_a865x___f_f___m_t___c_f_g__t.html#a6aba76c05822dc7222fc2c103861fa59',1,'MMA865x_FF_MT_CFG_t::oae()']]],
  ['orient_5fbkfr',['orient_bkfr',['../union_f_x_l_s8962___o_r_i_e_n_t___b_f___z_c_o_m_p__t.html#a035bbe55a5f8c8a5672ef93b433e37cc',1,'FXLS8962_ORIENT_BF_ZCOMP_t']]],
  ['orient_5fdbcntm',['orient_dbcntm',['../union_f_x_l_s8962___o_r_i_e_n_t___c_o_n_f_i_g__t.html#a2a4c917e5532704df5c9e9517de5cbd8',1,'FXLS8962_ORIENT_CONFIG_t']]],
  ['orient_5fen',['orient_en',['../union_f_x_l_s8962___i_n_t___e_n__t.html#aae46cbab86974c56f8944e4dd3fbe5b4',1,'FXLS8962_INT_EN_t']]],
  ['orient_5fenable',['orient_enable',['../union_f_x_l_s8962___o_r_i_e_n_t___c_o_n_f_i_g__t.html#a37dc0cb7f66249bd9b4d729d5b4309f1',1,'FXLS8962_ORIENT_CONFIG_t']]],
  ['orient_5fint2',['orient_int2',['../union_f_x_l_s8962___i_n_t___p_i_n___s_e_l__t.html#a3a410b281a5f43ee33ad7a397246c64e',1,'FXLS8962_INT_PIN_SEL_t']]],
  ['orient_5fths',['orient_ths',['../union_f_x_l_s8962___o_r_i_e_n_t___t_h_s___r_e_g__t.html#ac173fc90d63e5213559847bc38a66753',1,'FXLS8962_ORIENT_THS_REG_t']]],
  ['orient_5fzlock',['orient_zlock',['../union_f_x_l_s8962___o_r_i_e_n_t___b_f___z_c_o_m_p__t.html#a91c3c6d858d2417194324c00e4864b8f',1,'FXLS8962_ORIENT_BF_ZCOMP_t']]],
  ['ot_5fdbctm',['ot_dbctm',['../union_f_x_l_s8962___s_d_c_d___c_o_n_f_i_g2__t.html#a91a22268e0719c00acc4e2c6af487d49',1,'FXLS8962_SDCD_CONFIG2_t']]],
  ['ot_5fea',['ot_ea',['../union_f_x_l_s8962___s_d_c_d___i_n_t___s_r_c1__t.html#a76ffb62da2f53c3db4e56e949794f1c2',1,'FXLS8962_SDCD_INT_SRC1_t']]],
  ['ot_5fele',['ot_ele',['../union_f_x_l_s8962___s_d_c_d___c_o_n_f_i_g1__t.html#a02df5c5a0cfbebadd2c970a54e12bac7',1,'FXLS8962_SDCD_CONFIG1_t']]]
];
