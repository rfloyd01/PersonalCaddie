var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstvwxyz",
  1: "fmrs",
  2: "fims",
  3: "fms",
  4: "_abcdefghilmnoprstvwxyz",
  5: "fms",
  6: "fms",
  7: "afms",
  8: "_aefmnprstv",
  9: "ci"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

