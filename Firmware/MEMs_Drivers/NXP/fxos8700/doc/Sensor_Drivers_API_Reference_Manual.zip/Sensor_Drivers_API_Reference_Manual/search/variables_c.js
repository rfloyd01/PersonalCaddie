var searchData=
[
  ['new_5forient',['new_orient',['../union_f_x_l_s8962___o_r_i_e_n_t___s_t_a_t_u_s__t.html#a3cf93b0490cb9c79d408189306dd528b',1,'FXLS8962_ORIENT_STATUS_t']]],
  ['newlp',['newlp',['../union_f_x_o_s8700___p_l___s_t_a_t_u_s__t.html#a75fda6f706b71e0ca863c0ecec4d8d7b',1,'FXOS8700_PL_STATUS_t::newlp()'],['../union_f_x_l_s8471_q___p_l___s_t_a_t_u_s__t.html#a75fda6f706b71e0ca863c0ecec4d8d7b',1,'FXLS8471Q_PL_STATUS_t::newlp()'],['../union_m_m_a865x___p_l___s_t_a_t_u_s__t.html#a75fda6f706b71e0ca863c0ecec4d8d7b',1,'MMA865x_PL_STATUS_t::newlp()']]],
  ['numbytes',['numBytes',['../structregisterreadlist__t.html#a1440a8efa2f56cded09ced3ff687d32a',1,'registerreadlist_t']]]
];
