var searchData=
[
  ['no_5fdata_5fmask',['NO_DATA_MASK',['../sensor__common_8h.html#a54bc7936992590ffb530b3c9d29e2643',1,'sensor_common.h']]],
  ['num_5faxes',['NUM_AXES',['../fxos8700__driver_8h.html#a21adbd52ec4c70f91a0d0fc9c059b3b7',1,'NUM_AXES():&#160;fxos8700_driver.h'],['../fxls8471q__driver_8h.html#a21adbd52ec4c70f91a0d0fc9c059b3b7',1,'NUM_AXES():&#160;fxls8471q_driver.h'],['../mma865x__driver_8h.html#a21adbd52ec4c70f91a0d0fc9c059b3b7',1,'NUM_AXES():&#160;mma865x_driver.h'],['../fxls8962__driver_8h.html#a21adbd52ec4c70f91a0d0fc9c059b3b7',1,'NUM_AXES():&#160;fxls8962_driver.h']]]
];
