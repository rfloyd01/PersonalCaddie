var searchData=
[
  ['new_5forient',['new_orient',['../union_f_x_l_s8962___o_r_i_e_n_t___s_t_a_t_u_s__t.html#a3cf93b0490cb9c79d408189306dd528b',1,'FXLS8962_ORIENT_STATUS_t']]],
  ['newlp',['newlp',['../union_f_x_o_s8700___p_l___s_t_a_t_u_s__t.html#a75fda6f706b71e0ca863c0ecec4d8d7b',1,'FXOS8700_PL_STATUS_t::newlp()'],['../union_f_x_l_s8471_q___p_l___s_t_a_t_u_s__t.html#a75fda6f706b71e0ca863c0ecec4d8d7b',1,'FXLS8471Q_PL_STATUS_t::newlp()'],['../union_m_m_a865x___p_l___s_t_a_t_u_s__t.html#a75fda6f706b71e0ca863c0ecec4d8d7b',1,'MMA865x_PL_STATUS_t::newlp()']]],
  ['no_5fdata_5fmask',['NO_DATA_MASK',['../sensor__common_8h.html#a54bc7936992590ffb530b3c9d29e2643',1,'sensor_common.h']]],
  ['num_5faxes',['NUM_AXES',['../fxos8700__driver_8h.html#a21adbd52ec4c70f91a0d0fc9c059b3b7',1,'NUM_AXES():&#160;fxos8700_driver.h'],['../fxls8471q__driver_8h.html#a21adbd52ec4c70f91a0d0fc9c059b3b7',1,'NUM_AXES():&#160;fxls8471q_driver.h'],['../mma865x__driver_8h.html#a21adbd52ec4c70f91a0d0fc9c059b3b7',1,'NUM_AXES():&#160;mma865x_driver.h'],['../fxls8962__driver_8h.html#a21adbd52ec4c70f91a0d0fc9c059b3b7',1,'NUM_AXES():&#160;fxls8962_driver.h']]],
  ['numbytes',['numBytes',['../structregisterreadlist__t.html#a1440a8efa2f56cded09ced3ff687d32a',1,'registerreadlist_t']]]
];
