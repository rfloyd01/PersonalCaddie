var searchData=
[
  ['active',['ACTIVE',['../fxls8471q__driver_8c.html#a610f8aab050cadb242496e05c6b8cce9a33cf1d8ef1d06ee698a7fabf40eb3a7f',1,'ACTIVE():&#160;fxls8471q_driver.c'],['../fxls8962__driver_8c.html#a186aad09a8c86ba7d9827dcfe5571768a33cf1d8ef1d06ee698a7fabf40eb3a7f',1,'ACTIVE():&#160;fxls8962_driver.c']]]
];
