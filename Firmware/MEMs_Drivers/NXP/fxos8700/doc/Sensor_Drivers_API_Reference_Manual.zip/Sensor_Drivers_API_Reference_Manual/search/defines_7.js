var searchData=
[
  ['raw_5fmag_5fdata_5fsize',['RAW_MAG_DATA_SIZE',['../fxos8700__config_8c.html#a03882358ff7564c9a4b723d984afb7dc',1,'fxos8700_config.c']]]
];
