var searchData=
[
  ['_5f_5fend_5fread_5fdata_5f_5f',['__END_READ_DATA__',['../sensor__common_8h.html#aebb58a1bb3df30b7df4f6f14d0f1a81d',1,'sensor_common.h']]],
  ['_5f_5fend_5fwrite_5fdata_5f_5f',['__END_WRITE_DATA__',['../sensor__common_8h.html#a2cedde333a6373a3ee274bde6af145d0',1,'sensor_common.h']]]
];
